package com.cg.servletFiles;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.service.TraineeService;

/**
 * Servlet implementation class Delete
 */
@WebServlet("/Delete")
public class Delete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Delete() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String traineeId = request.getParameter("traineeId");
		if(traineeId == null || traineeId.length()==0) {
			request.setAttribute("errorMessage", "Id can not be Empty");
            RequestDispatcher rd = request.getRequestDispatcher("/addTrainee.jsp");
            rd.forward(request, response);  
		}
		int tId=0;
		try {
			tId = Integer.parseInt(traineeId);
		}catch (Exception e) {
			request.setAttribute("errorMessage", "Invalid Id");
			RequestDispatcher rd = request.getRequestDispatcher("/addTrainee.jsp");
            rd.forward(request, response);  
		}
		
		TraineeService service = new TraineeService();
		
		try {
			service.delete(tId);
			request.setAttribute("successMessage", "Trainee Inserted Successfully");
            RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
            rd.forward(request, response);  
		}catch (Exception e) {
			request.setAttribute("errorMessage", "Id Already Exists");
            RequestDispatcher rd = request.getRequestDispatcher("/addTrainee.jsp");
            rd.forward(request, response);  
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
