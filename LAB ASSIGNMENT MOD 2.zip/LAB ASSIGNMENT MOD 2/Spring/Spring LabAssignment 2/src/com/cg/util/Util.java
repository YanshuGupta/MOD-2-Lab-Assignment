package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Util {

	private static Connection con;
	private static Statement stmt;
	
	public static Connection getConnection(){
		try {
			//load the driver class  
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			
			//create  the connection object  
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Capgemini123");  
			
			return con;
		}
		catch(Exception e){
			System.out.println(e);
		}
		return null;  
	}
}
