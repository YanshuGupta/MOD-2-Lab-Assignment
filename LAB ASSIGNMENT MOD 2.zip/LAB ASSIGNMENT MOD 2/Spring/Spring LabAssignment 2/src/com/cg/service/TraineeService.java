package com.cg.service;

import com.cg.beans.Trainee;
import com.cg.dao.TraineeDao;

public class TraineeService {
	
	TraineeDao dao = new TraineeDao();
	
	public boolean logIn(String userName, String password) {
		return dao.logIn(userName, password);
	}
	
	public Trainee addTrainee(Trainee trainee) {
		
		if(dao.addTrainee(trainee)==null) {
			return null;
		}
		else {
			return trainee;
		}
	}

	public void delete(int tId) {
		
		
	}
}
