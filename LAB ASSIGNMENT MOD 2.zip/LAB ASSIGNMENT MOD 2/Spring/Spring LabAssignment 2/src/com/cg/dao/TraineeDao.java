package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.beans.Trainee;
import com.cg.util.Util;

public class TraineeDao {
	Connection con;
	public TraineeDao() {
		con = Util.getConnection();
	}

	public boolean logIn(String userName, String password) {
		return (userName.equals("YANSHU") && password.equals("GUPTA"));
	}
	
	public Trainee addTrainee(Trainee trainee) {
		
		PreparedStatement save;
		try {
			save = con.prepareStatement("INSERT INTO TRAINEE(TRAINEE_ID, TRAINEE_NAME, TRAINEE_LOCATION, TRAINEE_DOMAIN) VALUES(?, ?, ?, ?)");
			
			save.setInt(1, trainee.getTraineeId());
			save.setString(2, trainee.getTraineeName());
			save.setString(3, trainee.getTraineeLocation());
			save.setString(4, trainee.getTraineeDomain());
			
			save.executeQuery();
			save.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	
		return trainee;
	}
	
	
}

	
